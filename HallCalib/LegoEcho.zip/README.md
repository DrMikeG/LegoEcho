# LegoEcho
Hack to add echo location obstacle avoidance to Lego RC tracked racer

First off, saving some old code, before I start anything new.

Secondly, recording some URLs:

https://www.hackster.io/Notthemarsian/take-control-over-lego-power-functions-ee0bfa
(this is the place for me to start)

https://www.theengineeringprojects.com/2017/07/introduction-to-l293d.html
