# Sparkfun SX1509 C++ Library
Sparkfun SX1509 Port for RaspberryPI with WiringPI

Original files came from https://github.com/sparkfun/SparkFun_SX1509_Arduino_Library and i only ported it to wiringPI. Therefore you can find the API functions at sparkfun
